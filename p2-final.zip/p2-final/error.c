#include <stdio.h>
#include <stdlib.h>
#include "p2.h"

void error(char *m) {
    //fprintf(stderr, "line %d: %s\n", lineno, m);
    fprintf(stderr, "line %d: %s\n", 0, m);
    exit(1);
}

